import notifee, { AndroidImportance } from '@notifee/react-native';


async function displayNotification(poi, selectedLanguage) {

  await notifee.requestPermission();

  const channelId = await notifee.createChannel({
    id: 'test',
    name: 'sales',
    vibration: true,
    importance: AndroidImportance.HIGH,
  });

  //Definir o corpo da notificação
  let notificationBody = 'Está perto de um monumento!';

  if (selectedLanguage === 'en') {
    notificationBody = 'You are near a monument!';
  }
  if (selectedLanguage === 'fr') {
    notificationBody = "C'est proche d'un monument!";
  }
  if (selectedLanguage === 'de') {
    notificationBody = 'Es ist in der Nähe eines Denkmals!';
  }

  //Criar a notificação
  await notifee.displayNotification({
    id: '7',
    title: 'MovTour',
    body: notificationBody,
    android: {
      channelId,
      smallIcon: 'iconbk',
      pressAction: {
        id: 'default',
        launchActivity: 'default',
      },
    },
    data: { poi }, // Dados sobre o POI
  });

}
export { displayNotification };

