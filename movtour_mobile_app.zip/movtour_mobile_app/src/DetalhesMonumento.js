import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import './config/I18N/i18n';
import { useTranslation } from 'react-i18next';
import he from 'he';
import { useNavigation } from '@react-navigation/native';
import FontAwesomeIcon from 'react-native-vector-icons/FontAwesome';
import { WebView } from 'react-native-webview';

const DetalhesMonumento = ({ route }) => {

  const { poi } = route.params;
  const { t, i18n } = useTranslation();
  const navigation = useNavigation();
  const [selectedContentType, setSelectedContentType] = useState('Iniciação');
  const [showIMDbPage, setShowIMDbPage] = useState(false);
  const [imdbUrl, setImdbUrl] = useState('');

  //Criar o array com os tipos de conteúdo
  const contentTypes = [
    'Iniciação',
    'Divulgação',
    'Aprofundamento',
    'Investigação',
  ].map((contentType) => contentType);

  //Função para abrir a página do IMDb
  const handleMovieIconPress = (imdbUrl) => {
    if (imdbUrl) {
      setImdbUrl(imdbUrl);
      setShowIMDbPage(true);
    } else {
      console.error('Invalid IMDb URL');
    }
  };

  //Função para abrir o mapa
  const handleButtonPress = () => {
    navigation.navigate('MapaMonumento', { htmlScript });
  };
  const htmlScript = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Leaflet Map</title>
    <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7/leaflet.css">
    <style>
      body { padding: 0; margin: 0; }
      html, body, #map { height: 100%; width: 100%; }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <script src="http://cdn.leafletjs.com/leaflet-0.7/leaflet.js"></script>
    <script>
      const map = L.map('map').setView([${poi.latitude}, ${poi.longitude}], 15);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      }).addTo(map);
      L.marker([${poi.latitude}, ${poi.longitude}]).addTo(map)
        .bindPopup('${poi[`name_${i18n.language}`]}').openPopup();

    </script>
  </body>
  </html>
`;

  const [decodedDescription, setDecodedDescription] = useState('');
  const handleContentTypeChange = (contentType) => {
    setSelectedContentType(contentType);
  };

  // Atualiza a descrição do monumento quando o tipo de conteúdo é alterado
  useEffect(() => {
    console.log('selectedContentType:', selectedContentType);
    const descriptionObject = poi.poi_descriptions.find(
      (description) => description.description_type_name === selectedContentType
    );

    // Obter a descrição do monumento no idioma selecionado
    const selectedLanguageDescription = descriptionObject
      ? descriptionObject[`description_${i18n.language}`]
      : 'Description not found';

    // Remover as tags HTML da descrição
    const plainTextDescription = selectedLanguageDescription.replace(/<[^>]*>/g, '');
    const decodedDescription = he.decode(plainTextDescription);
    setDecodedDescription(decodedDescription);
  }, [selectedContentType]);

  return (
    <View style={styles.container}>
      {showIMDbPage ? (
        // Apresentar apenas o WebView quando showIMDbPage for true
        <WebView source={{ uri: imdbUrl }} onError={(syntheticEvent) => console.error('WebView error:', syntheticEvent.nativeEvent)} />
      ) : (
        //Apresentar o resto do conteúdo quando showIMDbPage for false
        <ScrollView>
          <Image source={{ uri: poi.cover_image }} style={styles.image} />
          <Text style={styles.monumentName}>{t(poi[`name_${i18n.language}`])}</Text>
          <TouchableOpacity onPress={handleButtonPress} style={styles.iconButton}>
            <FontAwesomeIcon name="map-pin" size={30} color="#E36509" /><FontAwesomeIcon />
          </TouchableOpacity>
          {/* Apresentar os botões com os tipos de conteúdo */}
          <ScrollView horizontal={true}>
            <View style={styles.buttonsContainer}>
              {contentTypes.map((contentType) => (
                <TouchableOpacity
                  key={contentType}
                  onPress={() => handleContentTypeChange(contentType)}
                  style={styles.button}
                >
                  <Text>
                    {contentType === 'Iniciação' ? t('Iniciação') :
                      contentType === 'Divulgação' ? t('Divulgação') :
                        contentType === 'Aprofundamento' ? t('Aprofundamento') :
                          contentType === 'Investigação' ? t('Investigação') : null}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
          <Text style={styles.container}>{decodedDescription}</Text>
          {/* Apresentar a lista de filmes ou séries gravados no local, se existir */}
          {poi.movies.length > 0 && (
            <>
              <Text style={styles.movieHeaderText}>{t('Filmes ou séries gravados neste local:')}</Text>
              <ScrollView horizontal={true}>
                <View style={styles.movieList}>
                  {poi.movies.map((movie, index) => (
                    <View key={`${movie.id}-${index}`} style={styles.movieItem}>
                      <TouchableOpacity onPress={() => handleMovieIconPress(movie.imdb)}>
                        <Image source={{ uri: movie.poster }} style={styles.poster} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              </ScrollView>
            </>
          )}
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#E8E8E8',
  },
  image: {
    width: '100%',
    height: 300,
    resizeMode: 'cover',
    borderWidth: 2,
    borderColor: '#CB7C05',
    position: 'relative',
  },
  poster: {
    width: '100%',
    height: 400,
    aspectRatio: 12 / 20,
    resizeMode: 'cover',
    borderWidth: 2,
    borderColor: '#CB7C05',
  },
  button: {
    backgroundColor: '#E36509',
    padding: 4,
    borderRadius: 10,
    marginTop: 2,
    alignItems: 'center',
  },
  movieList: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  iconButton: {
    position: 'absolute',
    top: 260,
    left: '90%',
    backgroundColor: 'transparent',
    alignItems: 'center',
    padding: 2,
  },
  monumentName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#CB7C05',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    marginBottom: 10,
  },
  movieHeaderText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#D75307',
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    marginBottom: 5,
  },
});

export default DetalhesMonumento;