import React, { useEffect, useState } from 'react';
import { StyleSheet, View, FlatList, Text, Image, TouchableOpacity, AppState } from 'react-native';
import './config/I18N/i18n';
import { useTranslation } from 'react-i18next';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BleManager } from 'react-native-ble-plx';
import { displayNotification } from './Notification';
import RNFetchBlob from 'rn-fetch-blob';
import { stringToBytes } from 'convert-string';
import notifee, { EventType } from '@notifee/react-native';
import i18n from './config/I18N/i18n';

const bleManager = new BleManager();
const jsonDataUrl = 'https://movtour.ipt.pt/monuments.json';
const navigation = useNavigation();

//Ir buscar os dados do JSON
async function fetchJsonData() {
  try {
    const response = await fetch(jsonDataUrl);
    const jsonData = await response.json();
    return jsonData;
  } catch (error) {
    console.error('Error fetching JSON data:', error);
    return null;
  }
}


//Funcionalidade de scan dos beacons
async function startBeaconScan() {
  const jsonData = await fetchJsonData();

  if (!jsonData) {
    console.error('Failed to fetch JSON data. Cannot compare beacons.');
    return;
  }

  const detectedBeacons = new Set(); //Guardar os beacons detetados

  //Iniciar o scan dos beacons
  bleManager.startDeviceScan(null, null, (error, device) => {
    if (error) {
      console.error('BLE scan error:', error);
      console.error('Error message:', error.message);
      return;
    }

    const base64 = RNFetchBlob.base64;
    const advertisingData = stringToBytes(base64.decode(device.manufacturerData)); //Descodificar os dados do beacon
    const majorM = advertisingData[21]; // Major
    const minorM = advertisingData[23]; // Minor
    const appState = AppState.currentState;
    const selectedLanguage = i18n.language;

    // Verificar se o beacon detetado é um duplicado
    if (!detectedBeacons.has(`${majorM}-${minorM}`)) {

      detectedBeacons.add(`${majorM}-${minorM}`); // Adicionar o beacon à lista de beacons detetados

      // Verificar se o beacon detetado corresponde a algum POI
      if (Array.isArray(jsonData.monuments)) {
        jsonData.monuments.forEach((monument) => {
          if (Array.isArray(monument.pois)) {
            monument.pois.forEach((poi) => {
              if (Array.isArray(poi.beacons)) {
                poi.beacons.forEach((beaconData) => {
                  if (
                    beaconData.major === majorM &&
                    beaconData.minor === minorM
                  ) {

                    // Verificar o estado da app
                    if (appState === 'active') {
                      navigation.navigate('DetalhesMonumento', { poi });
                      console.log('Estado da app', appState);
                    }
                    // Caso seja background, mostrar a notificação
                    if (appState === 'background') {
                      displayNotification(poi, selectedLanguage);
                      console.log('Estado da app', appState);
                    }

                    // Apresentar a hora do último scan
                    const now = new Date();
                    const hours = now.getHours().toString().padStart(2, '0');
                    const minutes = now.getMinutes().toString().padStart(2, '0');
                    const seconds = now.getSeconds().toString().padStart(2, '0');
                    console.log(`Último scan ocorreu às: ${hours}:${minutes}:${seconds}`);
                  }
                });
              } else {
                console.error('POI has no beacon data or invalid data:', poi);
              }
            });
          } else {
            console.error('Monument has no POI data or invalid data:', monument);
          }
        });
      } else {
        console.error('No monuments data found in JSON:', jsonData);
      }
    }
  });
}



//Lista de monumentos
const ListaMonumentos = () => {

  const { t, i18n } = useTranslation();
  const [data, setData] = useState([]);

  //Obter o nome do POI consoante a língua selecionada
  const getPoiName = (item, selectedLanguage) => {
    switch (selectedLanguage) {
      case 'en':
        return item.name_en;
      case 'fr':
        return item.name_fr;
      case 'de':
        return item.name_de;
      default:
        return item.name_pt; // Português por defeito
    }
  };


  useEffect(() => {
    // Tentar obter os dados em cache
    AsyncStorage.getItem('cachedData')
      .then((cachedData) => {
        if (cachedData) {
          // Usar os dados em cache se existirem
          setData(JSON.parse(cachedData));
        }
      })
      .catch((error) => {
        console.error('Error fetching cached data:', error);
      });

    // Ir buscar os dados ao JSON
    fetch('https://movtour.ipt.pt/monuments.json')
      .then((response) => response.json())
      .then((jsonData) => {
        // Fazer o flatten do array para obter todos os POIs
        const allPois = jsonData.monuments.flatMap((monument) => monument.pois);
        setData(allPois);

        // Guardar os dados em cache para uso futuro
        AsyncStorage.setItem('cachedData', JSON.stringify(allPois))
          .then(() => {
            console.log('Data cached successfully');
          })
          .catch((error) => {
            console.error('Error caching data:', error);
          });
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);


  // Notificações em primeiro plano
  useEffect(() => {

    return notifee.onForegroundEvent(({ type, detail }) => {
      switch (type) {
        case EventType.DISMISSED:
          console.log('User dismissed notification');
          break;
        case EventType.PRESS:
          console.log('User pressed an action button (Foreground)');
          const poi = detail.notification.data.poi;
          navigation.navigate('DetalhesMonumento', { poi });
          break;
      }
    });
  }, []);

  // Notificações em segundo plano
  useEffect(() => {
    return notifee.onBackgroundEvent(async ({ type, detail }) => {
      if (type === EventType.PRESS) {
        console.log('User pressed an action button (Background)');
        const poi = detail.notification.data.poi;
        navigation.navigate('DetalhesMonumento', { poi });
      }
    });
  }, []);



  // Ir para a página de detalhes do monumento
  const handleImageClick = (poi) => {
    navigation.navigate('DetalhesMonumento', { poi });
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.poiContainer, { marginRight: 3 }, { marginLeft: -1 }]}
            onPress={() => handleImageClick(item)}
          >
            <Image source={{ uri: item.cover_image }} style={styles.image} />
            <Text style={styles.customText}>{getPoiName(item, i18n.language)}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 5,
    backgroundColor: '#E8E8E8',
  },
  image: {
    width: '100%',
    height: 150,
    borderWidth: 2,
    borderColor: '#0066CC',
  },
  customText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#CB7C05',
    width: '100%',
    overflow: 'hidden',
    textAlign: 'center'
  },
  poiContainer: {
    width: '50%',
  },
});

export { ListaMonumentos, startBeaconScan };