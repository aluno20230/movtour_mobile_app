import { createDrawerNavigator } from '@react-navigation/drawer';
import About from './src/About';
import Mapa from './src/Mapa';
import Lingua from './src/Lingua';
import { NavigationContainer } from '@react-navigation/native';
import { StyleSheet, Image } from 'react-native';
import './src/config/I18N/i18n';
import { useTranslation } from 'react-i18next';
import { createStackNavigator } from '@react-navigation/stack';
import { ListaMonumentos, startBeaconScan } from './src/Monumentos';
import DetalhesMonumento from './src/DetalhesMonumento';
import MapaMonumento from './src/MapaMonumento';
import { PermissionsAndroid } from 'react-native';
import React, { useEffect } from 'react';
import { LogBox } from 'react-native';
LogBox.ignoreLogs(['new NativeEventEmitter']);
LogBox.ignoreAllLogs();
import { Alert } from 'react-native';
import { useState } from 'react';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

// Função que cria o menu de navegação
function StackNavigator() {
  const { t, i18n } = useTranslation();
  return (
    <Stack.Navigator>
      <Stack.Screen name={t(' Monumentos')} component={ListaMonumentos} options={{
        headerTitleAlign: 'center',
        headerTitleStyle: {
          color: '#CC6600',
          fontSize: 30,
        },
        headerStyle: {
          backgroundColor: '#E8E8E8',
        }
      }} />
      <Stack.Screen name={t('DetalhesMonumento')} component={DetalhesMonumento} options={{
        title: '',
        headerStyle: {
          backgroundColor: '#E8E8E8',
        },
      }} />
      <Stack.Screen name="MapaMonumento" component={MapaMonumento} options={{
        title: '',
        headerStyle: {
          backgroundColor: '#E8E8E8',
        },
      }} />
    </Stack.Navigator>

  );
}

// Função que cria o menu lateral
function DrawerNavigator() {
  const { t, i18n } = useTranslation();
  return (
    <Drawer.Navigator initialRouteName="Monumentos">
      <Drawer.Screen name={t('Monumentos')} component={StackNavigator}
        options={{
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: '#E8E8E8',
          },
          headerTitle: () => (
            <Image
              source={require('./src/config/pictures/movtour_logo.png')}
              style={{
                width: 50,
                height: 50,
              }}
            />
          ),
        }} />

      <Drawer.Screen name={t('Mapa')} component={Mapa}
        options={{
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: '#E8E8E8',
          },
          headerTitle: () => (
            <Image
              source={require('./src/config/pictures/movtour_logo.png')}
              style={{
                width: 50,
                height: 50,
              }}
            />
          ),
        }} />
      <Drawer.Screen name={t('Sobre nós')} component={About}
        options={{
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: '#E8E8E8',
          },
          headerTitle: () => (
            <Image
              source={require('./src/config/pictures/movtour_logo.png')}
              style={{
                width: 50,
                height: 50,
              }}
            />
          ),
        }} />
      <Drawer.Screen name={t('Língua')} component={Lingua}
        options={{
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: '#E8E8E8',
          },
          headerTitle: () => (
            <Image
              source={require('./src/config/pictures/movtour_logo.png')}
              style={{
                width: 50,
                height: 50,
              }}
            />
          ),
        }} />

    </Drawer.Navigator>
  );
}



// Função principal
function App() {

  const { t, i18n } = useTranslation();
  const locationDisclosureTitle = t('Recolha de Dados de Localização');
  const locationDisclosureMessage = t('Esta aplicação recolhe dados de localização para permitir o scanning de beacons, mesmo quando a aplicação está fechada ou não está em uso.');

  const [alertShown, setAlertShown] = useState(false);
  const [permissionsRequested, setPermissionsRequested] = useState(false);

  const handleApprovePress = () => {
    setAlertShown(true);
    setPermissionsRequested(true);
  };

  const handleDenyPress = () => {
    setAlertShown(true);
    Alert.alert(
      'Beacon scanning disabled',
      'Beacon scanning will be disabled until you enable location services for this app.',
      [{ text: 'OK' }]
    );
  };

  useEffect(() => {

    if (!alertShown) {
      Alert.alert(
        'Collection of Location Data',
        'MovTour collects location data to enable beacon scanning, even when the app is closed or not in use.',
        [
          { text: 'Deny', onPress: handleDenyPress },
          { text: 'Approve', onPress: handleApprovePress },
        ]
      );
    } else if (permissionsRequested) {


      async function requestPermissions() {

        //Localização
        try {

          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            {
              title: 'Location Permission',
              message: 'App needs access to location to detect beacons.',
              buttonNeutral: 'Ask Me Later',
              buttonNegative: 'Cancel',
              buttonPositive: 'OK',
            },
          );

          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            console.log('Location Permission granted.');

          } else {
            console.log('Location Permission denied.');
          }
        } catch (err) {
          console.warn(err);
          console.error('Location Permission error:', err);
        }

        //Bluetooth scan
        try {

          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            {
              title: 'Bluetooth scan Permission',
              message: 'App needs access to Bluetooth scan to detect beacons.',
              buttonNeutral: 'Ask Me Later',
              buttonNegative: 'Cancel',
              buttonPositive: 'OK',
            },
          );

          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            console.log('Bluetooth scan Permission granted.');

          } else {
            console.log('Bluetooth scan Permission denied.');
          }
        } catch (err) {
          console.warn(err);
          console.error('Bluetooth scan Permission error:', err);
        }

        //Bluetooth connect
        try {

          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
            {
              title: 'Bluetooth connect Permission',
              message: 'App needs access to Bluetooth connect to detect beacons.',
              buttonNeutral: 'Ask Me Later',
              buttonNegative: 'Cancel',
              buttonPositive: 'OK',
            },
          );

          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            console.log('Bluetooth connect Permission granted.');
            startBeaconScan();

          } else {
            console.log('Bluetooth connect Permission denied.');
          }
        } catch (err) {
          console.warn(err);
          console.error('Bluetooth connect Permission error:', err);
        }
      }
      // Chama a função que pede as permissões
      requestPermissions();
    }

  }, [alertShown, permissionsRequested]);

  // Retorna o menu de navegação
  return (
    <NavigationContainer>
      <DrawerNavigator />
    </NavigationContainer>

  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1
  },
  container: {
    flex: 1,
  },
  header: {
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  listItemBG: {
    backgroundColor: '#DFDFDF'
  },
  logo: {
    width: 75,
    height: 75,
  },
  flag: {
    width: 20,
    height: 20,
  },
})

export default App;