# movtour
#-------------------------------------------------------------------------------------------------------------------

# Necessário para correr o projeto inicialmente:

# npm install -g react-native-cli
# npm install 
# npm start

#Links de apoio:

# https://www.youtube.com/watch?v=8ejuHsaXiwU&ab_channel=GhostTogether
# https://stackoverflow.com/questions/38889487/react-native-is-not-recognized-as-an-internal-or-external-command-operable-pr

#---------------------------------------------------------------------------------------------------------------------
